CREATE VIEW prod_img_view AS
  (SELECT
     `p`.`id`           AS `id`,
     `p`.`cid`          AS `cid`,
     `p`.`name`         AS `pname`,
     `p`.`promotePrice` AS `promotePrice`,
     `pi`.`id`          AS `imgId`
   FROM (`tmalltest`.`product` `p`
     JOIN `tmalltest`.`productimage` `pi`)
   WHERE (`p`.`id` = `pi`.`pid`));

